package com.moonchat.app;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.webrtc.EglBase;
import org.webrtc.RendererCommon;
import org.webrtc.SurfaceViewRenderer;

/**
 * Full-screen native call screen: remote video fills the screen, local
 * camera is a small picture-in-picture, plus mute / speaker / camera /
 * end controls. The PeerConnection itself lives in NativeCallManager so
 * the call survives this activity; this screen only renders and controls.
 */
public class CallActivity extends AppCompatActivity implements NativeCallManager.UiListener {
    private NativeCallManager manager;
    private SurfaceViewRenderer remoteView;
    private SurfaceViewRenderer localView;
    private TextView avatarView;
    private TextView nameView;
    private TextView statusView;
    private TextView timerView;
    private Button muteBtn;
    private Button speakerBtn;
    private Button camBtn;
    private Button endBtn;
    private boolean isVideo;
    private boolean muted;
    private boolean camOff;
    private boolean speakerOn;
    private long connectedAt;
    private final Handler timerHandler = new Handler(Looper.getMainLooper());
    private final Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            if (connectedAt > 0) {
                long s = (System.currentTimeMillis() - connectedAt) / 1000;
                if (timerView != null) {
                    timerView.setText(String.format("%d:%02d", s / 60, s % 60));
                }
                timerHandler.postDelayed(this, 500);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // v1.15: trace FIRST — before super.onCreate(). v1.14's trace
        // showed the app dying between "activity launched" and
        // "onCreate start", but that trace sat AFTER super.onCreate +
        // setContentView + NativeCallManager.get, so the crash could
        // have been in any of those early lines (or in the concurrent
        // native PeerConnection threads). These finer steps pin it down.
        manager = NativeCallManager.get(this);
        manager.traceCall("onCreate enter");
        super.onCreate(savedInstanceState);
        manager.traceCall("onCreate super ok");
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_SECURE);
        setContentView(R.layout.activity_call);
        manager.traceCall("onCreate setContentView ok");

        isVideo = "video".equals(getIntent().getStringExtra("type"));
        manager.traceCall("onCreate start " + (isVideo ? "video" : "audio"));
        String name = getIntent().getStringExtra("name");
        String emoji = getIntent().getStringExtra("emoji");
        if (name == null || name.isEmpty()) name = "Moon User";
        if (emoji == null || emoji.isEmpty()) emoji = "\uD83C\uDF19";
        speakerOn = isVideo; // video calls start on speaker, audio on earpiece

        // v1.15: the two SurfaceViewRenderer views are NOT in the layout
        // any more — they are created in code below, only for video
        // calls, inside the try/catch. Audio calls never touch a
        // renderer view at all.
        avatarView = findViewById(R.id.call_avatar);
        nameView = findViewById(R.id.call_name);
        statusView = findViewById(R.id.call_status);
        timerView = findViewById(R.id.call_timer);
        muteBtn = findViewById(R.id.btn_mute);
        speakerBtn = findViewById(R.id.btn_speaker);
        camBtn = findViewById(R.id.btn_camera);
        endBtn = findViewById(R.id.btn_end);

        nameView.setText(name);
        avatarView.setText(emoji);
        statusView.setText("Calling…");
        timerView.setText("0:00");
        speakerBtn.setText(speakerOn ? "\uD83D\uDD0A" : "\uD83D\uDD08");

        // Video calls show the remote camera full-screen; audio calls show
        // a big avatar instead. (remoteView/localView are created in code
        // below for video calls only — they do not exist for audio.)
        avatarView.setVisibility(isVideo ? android.view.View.GONE : android.view.View.VISIBLE);
        camBtn.setVisibility(isVideo ? android.view.View.VISIBLE : android.view.View.GONE);

        // v1.14: EGL is only needed for video rendering. Audio calls
        // never touch EGL at all — getEglContext() used to run for both,
        // and EGL init itself is a native-crash suspect on this device,
        // so keep it out of the audio path entirely.
        // v1.15: the renderer views are created here in code (not in
        // the XML layout), so layout inflation can never touch a
        // SurfaceViewRenderer — an audio call creates no renderer
        // views at all.
        try {
            if (isVideo) {
                EglBase.Context eglContext = manager.getEglContext();
                android.widget.FrameLayout root = findViewById(R.id.call_root);
                remoteView = new SurfaceViewRenderer(this);
                remoteView.setLayoutParams(new android.widget.FrameLayout.LayoutParams(
                        android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                        android.widget.FrameLayout.LayoutParams.MATCH_PARENT));
                remoteView.setBackgroundColor(android.graphics.Color.BLACK);
                root.addView(remoteView, 0); // behind avatar, name, controls
                localView = new SurfaceViewRenderer(this);
                android.widget.FrameLayout.LayoutParams lp =
                        new android.widget.FrameLayout.LayoutParams(dp(110), dp(150));
                lp.gravity = android.view.Gravity.BOTTOM | android.view.Gravity.END;
                lp.rightMargin = dp(14);
                lp.bottomMargin = dp(110);
                localView.setLayoutParams(lp);
                localView.setBackgroundColor(0xFF111111);
                // PiP sits above the bottom controls (110dp bottom margin
                // vs ~82dp of controls), so appending last is safe.
                root.addView(localView);
                remoteView.init(eglContext, null);
                remoteView.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL);
                remoteView.setMirror(false);
                localView.init(eglContext, null);
                localView.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL);
                localView.setMirror(true);
            }
            manager.setCallActivity(this);
            manager.setUiListener(this);
            manager.attachRenderers(isVideo ? remoteView : null, isVideo ? localView : null);
        } catch (Throwable t) {
            android.util.Log.w("MoonCall", "call screen init failed", t);
            manager.traceCall("onCreate failed: " + t.getClass().getSimpleName()
                    + ": " + t.getMessage());
            try { manager.endCall(); } catch (Throwable ignored) {}
            finish();
            return;
        }

        if (manager.isEnded()) {
            finish();
            return;
        }
        if (manager.isConnected()) {
            onConnected();
        }

        muteBtn.setOnClickListener(v -> {
            muted = !muted;
            manager.setMuted(muted);
            muteBtn.setText(muted ? "\uD83D\uDD07" : "\uD83C\uDF99\uFE0F");
            muteBtn.setBackgroundResource(muted
                    ? R.drawable.call_btn_active : R.drawable.call_btn_circle);
        });
        speakerBtn.setOnClickListener(v -> {
            speakerOn = !speakerOn;
            manager.setSpeakerphone(speakerOn);
            speakerBtn.setText(speakerOn ? "\uD83D\uDD0A" : "\uD83D\uDD08");
            speakerBtn.setBackgroundResource(speakerOn
                    ? R.drawable.call_btn_active : R.drawable.call_btn_circle);
        });
        camBtn.setOnClickListener(v -> {
            camOff = !camOff;
            manager.setCameraOff(camOff);
            camBtn.setText(camOff ? "\uD83D\uDCF7" : "\uD83D\uDCF9");
            camBtn.setBackgroundResource(camOff
                    ? R.drawable.call_btn_active : R.drawable.call_btn_circle);
        });
        endBtn.setOnClickListener(v -> manager.endCall());
        manager.traceCall("onCreate done");
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onConnected() {
        runOnUiThread(() -> {
            if (statusView != null) statusView.setText("Connected");
            if (connectedAt == 0) {
                connectedAt = System.currentTimeMillis();
                timerHandler.post(timerRunnable);
            }
        });
    }

    @Override
    public void onEnded() {
        runOnUiThread(this::finish);
    }

    @Override
    public void onFailed() {
        runOnUiThread(this::finish);
    }

    @Override
    public void onBackPressed() {
        // Leaving the call screen hangs up, like the End button.
        manager.endCall();
    }

    @Override
    protected void onDestroy() {
        timerHandler.removeCallbacks(timerRunnable);
        manager.detachRenderers();
        manager.setCallActivity(null);
        manager.setUiListener(null);
        if (isVideo) {
            try { if (remoteView != null) remoteView.release(); } catch (Throwable ignored) {}
            try { if (localView != null) localView.release(); } catch (Throwable ignored) {}
        }
        super.onDestroy();
    }
}
