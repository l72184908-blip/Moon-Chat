package com.moonchat.app;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;
import org.webrtc.AudioSource;
import org.webrtc.AudioTrack;
import org.webrtc.Camera1Enumerator;
import org.webrtc.Camera2Enumerator;
import org.webrtc.CameraVideoCapturer;
import org.webrtc.DataChannel;
import org.webrtc.DefaultVideoDecoderFactory;
import org.webrtc.DefaultVideoEncoderFactory;
import org.webrtc.EglBase;
import org.webrtc.IceCandidate;
import org.webrtc.MediaConstraints;
import org.webrtc.MediaStream;
import org.webrtc.PeerConnection;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.RtpReceiver;
import org.webrtc.SdpObserver;
import org.webrtc.SessionDescription;
import org.webrtc.SurfaceTextureHelper;
import org.webrtc.SurfaceViewRenderer;
import org.webrtc.VideoCapturer;
import org.webrtc.VideoSource;
import org.webrtc.VideoTrack;
import org.webrtc.audio.JavaAudioDeviceModule;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Native WebRTC call engine.
 *
 * The user's phone cannot capture the mic through a WebView (getUserMedia
 * always fails with NotReadableError, even with permission granted and a
 * secure context), so live calls run on the native WebRTC stack instead —
 * the same bypass idea as the native voice recorder (MoonVoice), but for
 * real-time calls. Firestore signaling stays in the web app (index.html);
 * this class only owns the media: PeerConnection, camera, mic and video
 * rendering. Events flow back to JS via window.onNativeCallEvent(...).
 */
public class NativeCallManager {
    private static final String TAG = "MoonCall";
    private static NativeCallManager instance;

    /** Events delivered to the web app (JSON string for onNativeCallEvent). */
    public interface EventListener {
        void onCallEvent(String json);
    }

    /** UI callbacks for CallActivity (timer, status, finish). */
    public interface UiListener {
        void onConnected();
        void onEnded();
        void onFailed();
    }

    private final Context appContext;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private EventListener eventListener;
    private UiListener uiListener;
    private CallActivity callActivity;

    private EglBase eglBase;
    private PeerConnectionFactory factory;
    private PeerConnection pc;
    private VideoCapturer videoCapturer;
    private SurfaceTextureHelper surfaceTextureHelper;
    private VideoSource videoSource;
    private VideoTrack localVideoTrack;
    private AudioSource audioSource;
    private AudioTrack localAudioTrack;
    private VideoTrack remoteVideoTrack;
    private SurfaceViewRenderer remoteRenderer;
    private SurfaceViewRenderer localRenderer;

    private String callId;
    private String callType; // "audio" | "video"
    private String partnerName = "Moon User";
    private String partnerEmoji = "\uD83C\uDF19";
    private boolean connected;
    private boolean ended;
    private boolean remoteDescriptionSet;
    private boolean muted;
    private boolean cameraOff;
    private boolean speakerOn;
    private final List<IceCandidate> pendingCandidates = new ArrayList<>();

    private NativeCallManager(Context context) {
        this.appContext = context.getApplicationContext();
    }

    public static synchronized NativeCallManager get(Context context) {
        if (instance == null) instance = new NativeCallManager(context);
        return instance;
    }

    public void setEventListener(EventListener l) { eventListener = l; }
    public void setUiListener(UiListener l) { uiListener = l; }
    public void setCallActivity(CallActivity a) { callActivity = a; }
    public String getCallType() { return callType; }
    public String getPartnerName() { return partnerName; }
    public String getPartnerEmoji() { return partnerEmoji; }
    public boolean isConnected() { return connected; }
    public boolean isEnded() { return ended; }

    public EglBase.Context getEglContext() {
        ensureFactory();
        return eglBase.getEglBaseContext();
    }

    // ===== Entry points (safe to call from any thread) =====

    public void startCall(final String callId, final String type,
                          final String iceJson, final String name, final String emoji) {
        mainHandler.post(() -> startCallOnMain(callId, type, iceJson, name, emoji, null));
    }

    public void acceptCall(final String callId, final String type,
                           final String iceJson, final String offerJson,
                           final String name, final String emoji) {
        mainHandler.post(() -> startCallOnMain(callId, type, iceJson, name, emoji, offerJson));
    }

    public void setRemoteDescription(final String sdpJson) {
        mainHandler.post(() -> {
            if (pc == null || ended) return;
            try {
                JSONObject o = new JSONObject(sdpJson);
                SessionDescription sdp = new SessionDescription(
                        SessionDescription.Type.fromCanonicalForm(o.getString("type")),
                        o.getString("sdp"));
                pc.setRemoteDescription(sdpObserverForRemote(), sdp);
            } catch (Exception e) {
                Log.w(TAG, "setRemoteDescription failed", e);
            }
        });
    }

    public void addIceCandidate(final String candJson) {
        mainHandler.post(() -> {
            try {
                JSONObject o = new JSONObject(candJson);
                IceCandidate cand = new IceCandidate(
                        o.optString("sdpMid", null),
                        o.optInt("sdpMLineIndex", 0),
                        o.getString("candidate"));
                if (pc == null || ended) return;
                if (remoteDescriptionSet) {
                    pc.addIceCandidate(cand);
                } else {
                    // Candidates can arrive before the remote description is
                    // set (offer/answer and candidates travel on separate
                    // Firestore listeners) — queue them and flush after.
                    pendingCandidates.add(cand);
                }
            } catch (Exception e) {
                Log.w(TAG, "addIceCandidate failed", e);
            }
        });
    }

    public void setMuted(final boolean m) {
        mainHandler.post(() -> {
            muted = m;
            if (localAudioTrack != null) localAudioTrack.setEnabled(!m);
        });
    }

    public void setCameraOff(final boolean off) {
        mainHandler.post(() -> {
            cameraOff = off;
            if (localVideoTrack != null) localVideoTrack.setEnabled(!off);
        });
    }

    public void setSpeakerphone(final boolean on) {
        mainHandler.post(() -> {
            speakerOn = on;
            applySpeakerphone();
        });
    }

    public void endCall() {
        mainHandler.post(this::endCallOnMain);
    }

    /** Attach the activity's video views (called from CallActivity.onCreate). */
    public void attachRenderers(SurfaceViewRenderer remote, SurfaceViewRenderer local) {
        remoteRenderer = remote;
        localRenderer = local;
        if (remoteVideoTrack != null && remoteRenderer != null) {
            try { remoteVideoTrack.addSink(remoteRenderer); } catch (Exception ignored) {}
        }
        if (localVideoTrack != null && localRenderer != null) {
            try { localVideoTrack.addSink(localRenderer); } catch (Exception ignored) {}
        }
    }

    /** Detach video views (called from CallActivity.onDestroy). */
    public void detachRenderers() {
        if (remoteVideoTrack != null && remoteRenderer != null) {
            try { remoteVideoTrack.removeSink(remoteRenderer); } catch (Exception ignored) {}
        }
        if (localVideoTrack != null && localRenderer != null) {
            try { localVideoTrack.removeSink(localRenderer); } catch (Exception ignored) {}
        }
        remoteRenderer = null;
        localRenderer = null;
    }

    /** Release factory + EGL (call only when the app is going away). */
    public void release() {
        mainHandler.post(() -> {
            endCallOnMain();
            if (factory != null) {
                try { factory.dispose(); } catch (Exception ignored) {}
                factory = null;
            }
            if (eglBase != null) {
                try { eglBase.release(); } catch (Exception ignored) {}
                eglBase = null;
            }
        });
    }

    // ===== Call setup (main thread) =====

    private void startCallOnMain(String id, String type, String iceJson,
                                 String name, String emoji, String offerJson) {
        if (pc != null) return; // already in a call
        callId = id;
        callType = "video".equals(type) ? "video" : "audio";
        partnerName = (name != null && !name.isEmpty()) ? name : "Moon User";
        partnerEmoji = (emoji != null && !emoji.isEmpty()) ? emoji : "\uD83C\uDF19";
        connected = false;
        ended = false;
        remoteDescriptionSet = false;
        muted = false;
        cameraOff = false;
        pendingCandidates.clear();
        // Video calls default to speaker, audio calls to the earpiece.
        speakerOn = "video".equals(callType);
        try {
            ensureFactory();
            List<PeerConnection.IceServer> ice = parseIceServers(iceJson);
            PeerConnection.RTCConfiguration config = new PeerConnection.RTCConfiguration(ice);
            config.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN;
            pc = factory.createPeerConnection(config, pcObserver);
            if (pc == null) throw new IllegalStateException("createPeerConnection returned null");

            audioSource = factory.createAudioSource(new MediaConstraints());
            localAudioTrack = factory.createAudioTrack("ARDAMSa0", audioSource);
            pc.addTrack(localAudioTrack, Arrays.asList("ARDAMS"));

            if ("video".equals(callType)) {
                startCamera();
            }

            if (offerJson == null) {
                // Caller: create the offer.
                pc.createOffer(new SdpObserver() {
                    @Override public void onCreateSuccess(SessionDescription sdp) {
                        mainHandler.post(() -> {
                            if (pc == null || ended) return;
                            pc.setLocalDescription(new SdpObserver() {
                                @Override public void onCreateSuccess(SessionDescription s) {}
                                @Override public void onSetSuccess() {
                                    fireLocalDescription("offer", sdp);
                                }
                                @Override public void onCreateFailure(String e) {}
                                @Override public void onSetFailure(String e) { onMediaFailed(); }
                            }, sdp);
                        });
                    }
                    @Override public void onSetSuccess() {}
                    @Override public void onCreateFailure(String e) { onMediaFailed(); }
                    @Override public void onSetFailure(String e) {}
                }, new MediaConstraints());
            } else {
                // Callee: apply the offer first; the answer is created
                // once setRemoteDescription succeeds (calling createAnswer
                // before that fails in the wrong state).
                JSONObject o = new JSONObject(offerJson);
                SessionDescription offer = new SessionDescription(
                        SessionDescription.Type.fromCanonicalForm(o.getString("type")),
                        o.getString("sdp"));
                pc.setRemoteDescription(sdpObserverForRemote(this::createAnswer), offer);
            }
            launchCallActivity();
            applySpeakerphone();
        } catch (Exception e) {
            Log.w(TAG, "startCall failed", e);
            cleanupMedia();
            fireEvent("failed", null);
        }
    }

    /** Create the callee's answer (only after the offer was applied). */
    private void createAnswer() {
        if (pc == null || ended) return;
        pc.createAnswer(new SdpObserver() {
            @Override public void onCreateSuccess(SessionDescription sdp) {
                mainHandler.post(() -> {
                    if (pc == null || ended) return;
                    pc.setLocalDescription(new SdpObserver() {
                        @Override public void onCreateSuccess(SessionDescription s) {}
                        @Override public void onSetSuccess() {
                            fireLocalDescription("answer", sdp);
                        }
                        @Override public void onCreateFailure(String e) {}
                        @Override public void onSetFailure(String e) { onMediaFailed(); }
                    }, sdp);
                });
            }
            @Override public void onSetSuccess() {}
            @Override public void onCreateFailure(String e) { onMediaFailed(); }
            @Override public void onSetFailure(String e) {}
        }, new MediaConstraints());
    }

    /**
     * SdpObserver for setRemoteDescription: marks the remote description
     * as set, flushes queued ICE candidates, then runs onSuccess (used
     * by the callee to create the answer).
     */
    private SdpObserver sdpObserverForRemote(final Runnable onSuccess) {
        return new SdpObserver() {
            @Override public void onCreateSuccess(SessionDescription s) {}
            @Override public void onSetSuccess() {
                mainHandler.post(() -> {
                    remoteDescriptionSet = true;
                    if (pc != null && !ended) {
                        for (IceCandidate c : pendingCandidates) {
                            try { pc.addIceCandidate(c); } catch (Exception ignored) {}
                        }
                    }
                    pendingCandidates.clear();
                    if (onSuccess != null) onSuccess.run();
                });
            }
            @Override public void onCreateFailure(String e) {}
            @Override public void onSetFailure(String e) { onMediaFailed(); }
        };
    }

    private SdpObserver sdpObserverForRemote() {
        return sdpObserverForRemote(null);
    }

    private void startCamera() throws Exception {
        VideoCapturer capturer = createCameraCapturer();
        if (capturer == null) throw new IllegalStateException("no camera found");
        videoCapturer = capturer;
        surfaceTextureHelper = SurfaceTextureHelper.create("CaptureThread", eglBase.getEglBaseContext());
        videoSource = factory.createVideoSource(false);
        videoCapturer.initialize(surfaceTextureHelper, appContext, videoSource.getCapturerObserver());
        localVideoTrack = factory.createVideoTrack("ARDAMSv0", videoSource);
        pc.addTrack(localVideoTrack, Arrays.asList("ARDAMS"));
        videoCapturer.startCapture(640, 480, 30);
        if (localRenderer != null) {
            try { localVideoTrack.addSink(localRenderer); } catch (Exception ignored) {}
        }
    }

    private VideoCapturer createCameraCapturer() {
        CameraVideoCapturer.CameraEventsHandler events = new CameraVideoCapturer.CameraEventsHandler() {
            @Override public void onCameraError(String e) { Log.w(TAG, "camera error: " + e); }
            @Override public void onCameraDisconnected() {}
            @Override public void onCameraFreezed(String e) {}
            @Override public void onCameraOpening(String id) {}
            @Override public void onFirstFrameAvailable() {}
            @Override public void onCameraClosed() {}
        };
        if (Camera2Enumerator.isSupported(appContext)) {
            Camera2Enumerator enumerator = new Camera2Enumerator(appContext);
            for (String name : enumerator.getDeviceNames()) {
                if (enumerator.isFrontFacing(name)) {
                    return enumerator.createCapturer(name, events);
                }
            }
            String[] names = enumerator.getDeviceNames();
            if (names.length > 0) return enumerator.createCapturer(names[0], events);
        }
        Camera1Enumerator enumerator = new Camera1Enumerator(true);
        for (String name : enumerator.getDeviceNames()) {
            if (enumerator.isFrontFacing(name)) {
                return enumerator.createCapturer(name, events);
            }
        }
        String[] names = enumerator.getDeviceNames();
        if (names.length > 0) return enumerator.createCapturer(names[0], events);
        return null;
    }

    private void launchCallActivity() {
        Intent i = new Intent(appContext, CallActivity.class);
        i.putExtra("callId", callId);
        i.putExtra("type", callType);
        i.putExtra("name", partnerName);
        i.putExtra("emoji", partnerEmoji);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        appContext.startActivity(i);
    }

    // ===== Teardown (main thread) =====

    private void endCallOnMain() {
        if (ended) {
            finishActivity();
            return;
        }
        ended = true;
        cleanupMedia();
        fireEvent("ended", null);
        finishActivity();
        if (uiListener != null) uiListener.onEnded();
        // Restore normal audio routing a moment later, once the WebRTC
        // audio device has wound down.
        mainHandler.postDelayed(() -> {
            try {
                AudioManager am = (AudioManager) appContext.getSystemService(Context.AUDIO_SERVICE);
                if (am != null) {
                    am.setMode(AudioManager.MODE_NORMAL);
                    am.setSpeakerphoneOn(false);
                }
            } catch (Exception ignored) {}
        }, 500);
    }

    private void finishActivity() {
        if (callActivity != null) {
            final CallActivity a = callActivity;
            callActivity = null;
            try { a.finish(); } catch (Exception ignored) {}
        }
    }

    private void cleanupMedia() {
        if (pc != null) {
            try { pc.close(); } catch (Exception ignored) {}
            try { pc.dispose(); } catch (Exception ignored) {}
            pc = null;
        }
        if (videoCapturer != null) {
            try { videoCapturer.stopCapture(); } catch (Exception ignored) {}
            try { videoCapturer.dispose(); } catch (Exception ignored) {}
            videoCapturer = null;
        }
        if (videoSource != null) {
            try { videoSource.dispose(); } catch (Exception ignored) {}
            videoSource = null;
        }
        if (surfaceTextureHelper != null) {
            try { surfaceTextureHelper.dispose(); } catch (Exception ignored) {}
            surfaceTextureHelper = null;
        }
        if (localVideoTrack != null) {
            try { localVideoTrack.dispose(); } catch (Exception ignored) {}
            localVideoTrack = null;
        }
        if (localAudioTrack != null) {
            try { localAudioTrack.dispose(); } catch (Exception ignored) {}
            localAudioTrack = null;
        }
        if (audioSource != null) {
            try { audioSource.dispose(); } catch (Exception ignored) {}
            audioSource = null;
        }
        remoteVideoTrack = null;
        pendingCandidates.clear();
        remoteDescriptionSet = false;
    }

    private void onMediaFailed() {
        mainHandler.post(() -> {
            if (ended) return;
            fireEvent("failed", null);
            if (uiListener != null) uiListener.onFailed();
            // Safety net: make sure the call is torn down even if the
            // web app does not answer the failure event.
            mainHandler.postDelayed(this::endCallOnMain, 500);
        });
    }

    // ===== Factory =====

    private void ensureFactory() {
        if (factory != null) return;
        PeerConnectionFactory.initialize(
                PeerConnectionFactory.InitializationOptions.builder(appContext)
                        .createInitializationOptions());
        eglBase = EglBase.create();
        JavaAudioDeviceModule adm = JavaAudioDeviceModule.builder(appContext)
                .setUseHardwareAcousticEchoCanceler(true)
                .setUseHardwareNoiseSuppressor(true)
                .createAudioDeviceModule();
        factory = PeerConnectionFactory.builder()
                .setAudioDeviceModule(adm)
                .setVideoEncoderFactory(new DefaultVideoEncoderFactory(
                        eglBase.getEglBaseContext(), true, true))
                .setVideoDecoderFactory(new DefaultVideoDecoderFactory(
                        eglBase.getEglBaseContext()))
                .createPeerConnectionFactory();
    }

    private void applySpeakerphone() {
        try {
            AudioManager am = (AudioManager) appContext.getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                am.setMode(AudioManager.MODE_IN_COMMUNICATION);
                am.setSpeakerphoneOn(speakerOn);
            }
        } catch (Exception ignored) {}
    }

    // ===== Signaling helpers =====

    private List<PeerConnection.IceServer> parseIceServers(String iceJson) throws Exception {
        List<PeerConnection.IceServer> servers = new ArrayList<>();
        JSONArray arr = new JSONArray(iceJson);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            List<String> urls = new ArrayList<>();
            Object u = o.get("urls");
            if (u instanceof JSONArray) {
                JSONArray ua = (JSONArray) u;
                for (int j = 0; j < ua.length(); j++) urls.add(ua.getString(j));
            } else {
                urls.add(o.getString("urls"));
            }
            PeerConnection.IceServer.Builder b = PeerConnection.IceServer.builder(urls);
            if (o.has("username")) b.setUsername(o.optString("username"));
            if (o.has("credential")) b.setPassword(o.optString("credential"));
            servers.add(b.createIceServer());
        }
        return servers;
    }

    private void fireLocalDescription(String type, SessionDescription sdp) {
        try {
            JSONObject s = new JSONObject();
            s.put("type", type);
            s.put("sdp", sdp.description);
            JSONObject ev = new JSONObject();
            ev.put("type", "localDescription");
            ev.put("sdp", s);
            fireEvent(ev);
        } catch (Exception ignored) {}
    }

    private void fireEvent(String type, JSONObject extra) {
        try {
            JSONObject ev = new JSONObject();
            ev.put("type", type);
            if (extra != null) {
                java.util.Iterator<String> keys = extra.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    ev.put(k, extra.get(k));
                }
            }
            fireEvent(ev);
        } catch (Exception ignored) {}
    }

    private void fireEvent(JSONObject ev) {
        if (eventListener == null) return;
        final String json = ev.toString();
        eventListener.onCallEvent(json);
    }

    private final PeerConnection.Observer pcObserver = new PeerConnection.Observer() {
        @Override public void onSignalingChange(PeerConnection.SignalingState s) {}
        @Override public void onIceConnectionChange(PeerConnection.IceConnectionState s) {}
        @Override public void onIceConnectionReceivingChange(boolean b) {}
        @Override public void onIceGatheringChange(PeerConnection.IceGatheringState s) {}
        @Override public void onIceCandidate(final IceCandidate cand) {
            mainHandler.post(() -> {
                try {
                    JSONObject c = new JSONObject();
                    c.put("candidate", cand.sdp);
                    c.put("sdpMid", cand.sdpMid);
                    c.put("sdpMLineIndex", cand.sdpMLineIndex);
                    JSONObject ev = new JSONObject();
                    ev.put("type", "iceCandidate");
                    ev.put("candidate", c);
                    fireEvent(ev);
                } catch (Exception ignored) {}
            });
        }
        @Override public void onIceCandidatesRemoved(IceCandidate[] c) {}
        @Override public void onAddStream(MediaStream stream) {
            mainHandler.post(() -> {
                if (stream.videoTracks != null && !stream.videoTracks.isEmpty()) {
                    attachRemoteVideo(stream.videoTracks.get(0));
                }
            });
        }
        @Override public void onRemoveStream(MediaStream stream) {}
        @Override public void onDataChannel(DataChannel dc) {}
        @Override public void onRenegotiationNeeded() {}
        @Override public void onAddTrack(RtpReceiver receiver, MediaStream[] streams) {
            mainHandler.post(() -> {
                if (receiver != null && receiver.track() instanceof VideoTrack) {
                    attachRemoteVideo((VideoTrack) receiver.track());
                }
            });
        }
        @Override public void onConnectionChange(PeerConnection.PeerConnectionState state) {
            mainHandler.post(() -> {
                if (ended) return;
                if (state == PeerConnection.PeerConnectionState.CONNECTED) {
                    if (!connected) {
                        connected = true;
                        applySpeakerphone();
                        fireEvent("connected", null);
                        if (uiListener != null) uiListener.onConnected();
                    }
                } else if (state == PeerConnection.PeerConnectionState.FAILED) {
                    onMediaFailed();
                }
            });
        }
    };

    private void attachRemoteVideo(VideoTrack track) {
        remoteVideoTrack = track;
        if (remoteRenderer != null) {
            try { track.addSink(remoteRenderer); } catch (Exception ignored) {}
        }
    }
}
