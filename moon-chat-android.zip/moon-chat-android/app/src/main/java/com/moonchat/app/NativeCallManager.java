package com.moonchat.app;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;
import org.webrtc.AudioSource;
import org.webrtc.AudioTrack;
import org.webrtc.Camera1Enumerator;
import org.webrtc.Camera2Enumerator;
import org.webrtc.CameraVideoCapturer;
import org.webrtc.DataChannel;
import org.webrtc.DefaultVideoDecoderFactory;
import org.webrtc.DefaultVideoEncoderFactory;
import org.webrtc.EglBase;
import org.webrtc.IceCandidate;
import org.webrtc.MediaConstraints;
import org.webrtc.MediaStream;
import org.webrtc.PeerConnection;
import org.webrtc.PeerConnectionFactory;
import org.webrtc.RtpReceiver;
import org.webrtc.SdpObserver;
import org.webrtc.SessionDescription;
import org.webrtc.SurfaceTextureHelper;
import org.webrtc.SurfaceViewRenderer;
import org.webrtc.VideoCapturer;
import org.webrtc.VideoSource;
import org.webrtc.VideoTrack;
import org.webrtc.audio.JavaAudioDeviceModule;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Native WebRTC call engine.
 *
 * The user's phone cannot capture the mic through a WebView (getUserMedia
 * always fails with NotReadableError, even with permission granted and a
 * secure context), so live calls run on the native WebRTC stack instead —
 * the same bypass idea as the native voice recorder (MoonVoice), but for
 * real-time calls. Firestore signaling stays in the web app (index.html);
 * this class only owns the media: PeerConnection, camera, mic and video
 * rendering. Events flow back to JS via window.onNativeCallEvent(...).
 */
public class NativeCallManager {
    private static final String TAG = "MoonCall";
    private static NativeCallManager instance;

    /** Events delivered to the web app (JSON string for onNativeCallEvent). */
    public interface EventListener {
        void onCallEvent(String json);
    }

    /** UI callbacks for CallActivity (timer, status, finish). */
    public interface UiListener {
        void onConnected();
        void onEnded();
        void onFailed();
    }

    private final Context appContext;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private EventListener eventListener;
    private UiListener uiListener;
    private CallActivity callActivity;

    private EglBase eglBase;
    private PeerConnectionFactory factory;
    private PeerConnection pc;
    private VideoCapturer videoCapturer;
    private SurfaceTextureHelper surfaceTextureHelper;
    private VideoSource videoSource;
    private VideoTrack localVideoTrack;
    private AudioSource audioSource;
    private AudioTrack localAudioTrack;
    private VideoTrack remoteVideoTrack;
    private SurfaceViewRenderer remoteRenderer;
    private SurfaceViewRenderer localRenderer;

    private String callId;
    private String callType; // "audio" | "video"
    private String partnerName = "Moon User";
    private String partnerEmoji = "\uD83C\uDF19";
    private boolean connected;
    private boolean ended;
    private boolean remoteDescriptionSet;
    private boolean muted;
    private boolean cameraOff;
    private boolean speakerOn;
    private final List<IceCandidate> pendingCandidates = new ArrayList<>();
    private volatile String lastFailureReason; // v1.11: exact reason of the last call failure

    private NativeCallManager(Context context) {
        this.appContext = context.getApplicationContext();
    }

    public static synchronized NativeCallManager get(Context context) {
        if (instance == null) instance = new NativeCallManager(context);
        return instance;
    }

    public void setEventListener(EventListener l) { eventListener = l; }
    public void setUiListener(UiListener l) { uiListener = l; }
    public void setCallActivity(CallActivity a) { callActivity = a; }
    public String getCallType() { return callType; }
    public String getPartnerName() { return partnerName; }
    public String getPartnerEmoji() { return partnerEmoji; }
    public boolean isConnected() { return connected; }
    public boolean isEnded() { return ended; }

    // ===== Call-step trace (v1.14) =====
    // A native crash (libjingle .so) cannot be caught by the Java
    // uncaught handler, so nothing is recorded when the app dies
    // mid-call. This trace appends one timestamped line per call step
    // to SharedPreferences with commit() (synchronous) — an async
    // apply() could be lost by the crash. After a crash the user can
    // read it in Settings → About and report exactly how far the call
    // got. Keeps only the last ~30 lines.
    public void traceCall(String step) {
        try {
            android.content.SharedPreferences prefs =
                    appContext.getSharedPreferences("moon_call_trace",
                            android.content.Context.MODE_PRIVATE);
            String prev = prefs.getString("trace", "");
            String line = new java.text.SimpleDateFormat("HH:mm:ss",
                    java.util.Locale.US).format(new java.util.Date())
                    + " " + step;
            String next = prev.isEmpty() ? line : prev + "\n" + line;
            String[] lines = next.split("\n");
            if (lines.length > 30) {
                StringBuilder sb = new StringBuilder();
                for (int i = lines.length - 30; i < lines.length; i++) {
                    if (sb.length() > 0) sb.append("\n");
                    sb.append(lines[i]);
                }
                next = sb.toString();
            }
            prefs.edit().putString("trace", next).commit();
        } catch (Throwable ignored) {}
    }

    public String getCallTrace() {
        try {
            return appContext.getSharedPreferences("moon_call_trace",
                    android.content.Context.MODE_PRIVATE).getString("trace", "");
        } catch (Throwable ignored) { return ""; }
    }

    public EglBase.Context getEglContext() {
        ensureFactory();
        return eglBase.getEglBaseContext();
    }

    // ===== Entry points (safe to call from any thread) =====

    public void startCall(final String callId, final String type,
                          final String iceJson, final String name, final String emoji) {
        traceCall("startCall " + type);
        mainHandler.post(() -> startCallOnMain(callId, type, iceJson, name, emoji, null));
    }

    public void acceptCall(final String callId, final String type,
                           final String iceJson, final String offerJson,
                           final String name, final String emoji) {
        traceCall("acceptCall " + type);
        mainHandler.post(() -> startCallOnMain(callId, type, iceJson, name, emoji, offerJson));
    }

    public void setRemoteDescription(final String sdpJson) {
        mainHandler.post(() -> {
            if (pc == null || ended) return;
            try {
                JSONObject o = new JSONObject(sdpJson);
                SessionDescription sdp = new SessionDescription(
                        SessionDescription.Type.fromCanonicalForm(o.getString("type")),
                        o.getString("sdp"));
                pc.setRemoteDescription(sdpObserverForRemote(), sdp);
            } catch (Throwable e) {
                Log.w(TAG, "setRemoteDescription failed", e);
            }
        });
    }

    public void addIceCandidate(final String candJson) {
        mainHandler.post(() -> {
            try {
                JSONObject o = new JSONObject(candJson);
                IceCandidate cand = new IceCandidate(
                        o.optString("sdpMid", null),
                        o.optInt("sdpMLineIndex", 0),
                        o.getString("candidate"));
                if (pc == null || ended) return;
                if (remoteDescriptionSet) {
                    pc.addIceCandidate(cand);
                } else {
                    // Candidates can arrive before the remote description is
                    // set (offer/answer and candidates travel on separate
                    // Firestore listeners) — queue them and flush after.
                    pendingCandidates.add(cand);
                }
            } catch (Throwable e) {
                Log.w(TAG, "addIceCandidate failed", e);
            }
        });
    }

    public void setMuted(final boolean m) {
        mainHandler.post(() -> {
            try {
                muted = m;
                if (localAudioTrack != null) localAudioTrack.setEnabled(!m);
            } catch (Throwable ignored) {}
        });
    }

    public void setCameraOff(final boolean off) {
        mainHandler.post(() -> {
            try {
                cameraOff = off;
                if (localVideoTrack != null) localVideoTrack.setEnabled(!off);
            } catch (Throwable ignored) {}
        });
    }

    public void setSpeakerphone(final boolean on) {
        mainHandler.post(() -> {
            try {
                speakerOn = on;
                applySpeakerphone();
            } catch (Throwable ignored) {}
        });
    }

    public void endCall() {
        mainHandler.post(this::endCallOnMain);
    }

    /** Attach the activity's video views (called from CallActivity.onCreate). */
    public void attachRenderers(SurfaceViewRenderer remote, SurfaceViewRenderer local) {
        remoteRenderer = remote;
        localRenderer = local;
        if (remoteVideoTrack != null && remoteRenderer != null) {
            try { remoteVideoTrack.addSink(remoteRenderer); } catch (Throwable ignored) {}
        }
        if (localVideoTrack != null && localRenderer != null) {
            try { localVideoTrack.addSink(localRenderer); } catch (Throwable ignored) {}
        }
    }

    /** Detach video views (called from CallActivity.onDestroy). */
    public void detachRenderers() {
        if (remoteVideoTrack != null && remoteRenderer != null) {
            try { remoteVideoTrack.removeSink(remoteRenderer); } catch (Throwable ignored) {}
        }
        if (localVideoTrack != null && localRenderer != null) {
            try { localVideoTrack.removeSink(localRenderer); } catch (Throwable ignored) {}
        }
        remoteRenderer = null;
        localRenderer = null;
    }

    /** Release factory + EGL (call only when the app is going away). */
    public void release() {
        mainHandler.post(() -> {
            endCallOnMain();
            if (factory != null) {
                try { factory.dispose(); } catch (Throwable ignored) {}
                factory = null;
            }
            if (eglBase != null) {
                try { eglBase.release(); } catch (Throwable ignored) {}
                eglBase = null;
            }
        });
    }

    // ===== Call setup (main thread) =====

    private void startCallOnMain(String id, String type, String iceJson,
                                 String name, String emoji, String offerJson) {
        if (pc != null) return; // already in a call
        callId = id;
        callType = "video".equals(type) ? "video" : "audio";
        partnerName = (name != null && !name.isEmpty()) ? name : "Moon User";
        partnerEmoji = (emoji != null && !emoji.isEmpty()) ? emoji : "\uD83C\uDF19";
        connected = false;
        ended = false;
        remoteDescriptionSet = false;
        muted = false;
        cameraOff = false;
        pendingCandidates.clear();
        // Video calls default to speaker, audio calls to the earpiece.
        speakerOn = "video".equals(callType);
        try {
            ensureFactory();
            traceCall("ensureFactory ok");
            List<PeerConnection.IceServer> ice = parseIceServers(iceJson);
            PeerConnection.RTCConfiguration config = new PeerConnection.RTCConfiguration(ice);
            config.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN;
            pc = factory.createPeerConnection(config, pcObserver);
            if (pc == null) throw new IllegalStateException("createPeerConnection returned null");
            traceCall("pc created");

            audioSource = factory.createAudioSource(new MediaConstraints());
            localAudioTrack = factory.createAudioTrack("ARDAMSa0", audioSource);
            pc.addTrack(localAudioTrack, Arrays.asList("ARDAMS"));

            if ("video".equals(callType)) {
                startCamera();
            }

            if (offerJson == null) {
                // Caller: create the offer.
                traceCall("offer requested");
                pc.createOffer(new SdpObserver() {
                    @Override public void onCreateSuccess(SessionDescription sdp) {
                        traceCall("offer created");
                        mainHandler.post(() -> {
                            if (pc == null || ended) return;
                            pc.setLocalDescription(new SdpObserver() {
                                @Override public void onCreateSuccess(SessionDescription s) {}
                                @Override public void onSetSuccess() {
                                    fireLocalDescription("offer", sdp);
                                }
                                @Override public void onCreateFailure(String e) {}
                                @Override public void onSetFailure(String e) { lastFailureReason = "setLocalDescription failed: " + e; onMediaFailed(); }
                            }, sdp);
                        });
                    }
                    @Override public void onSetSuccess() {}
                    @Override public void onCreateFailure(String e) { lastFailureReason = "createOffer failed: " + e; onMediaFailed(); }
                    @Override public void onSetFailure(String e) {}
                }, new MediaConstraints());
            } else {
                // Callee: apply the offer first; the answer is created
                // once setRemoteDescription succeeds (calling createAnswer
                // before that fails in the wrong state).
                JSONObject o = new JSONObject(offerJson);
                SessionDescription offer = new SessionDescription(
                        SessionDescription.Type.fromCanonicalForm(o.getString("type")),
                        o.getString("sdp"));
                pc.setRemoteDescription(sdpObserverForRemote(this::createAnswer), offer);
            }
            launchCallActivity();
            traceCall("activity launched");
            applySpeakerphone();
        } catch (Throwable e) {
            Log.w(TAG, "startCall failed", e);
            String reason = e.getClass().getSimpleName() + ": " + (e.getMessage() != null ? e.getMessage() : "");
            cleanupMedia();
            reportCallFailure(reason, e);
        }
    }

    /** Create the callee's answer (only after the offer was applied). */
    private void createAnswer() {
        if (pc == null || ended) return;
        pc.createAnswer(new SdpObserver() {
            @Override public void onCreateSuccess(SessionDescription sdp) {
                traceCall("answer created");
                mainHandler.post(() -> {
                    if (pc == null || ended) return;
                    pc.setLocalDescription(new SdpObserver() {
                        @Override public void onCreateSuccess(SessionDescription s) {}
                        @Override public void onSetSuccess() {
                            fireLocalDescription("answer", sdp);
                        }
                        @Override public void onCreateFailure(String e) {}
                        @Override public void onSetFailure(String e) { lastFailureReason = "setLocalDescription failed: " + e; onMediaFailed(); }
                    }, sdp);
                });
            }
            @Override public void onSetSuccess() {}
            @Override public void onCreateFailure(String e) { lastFailureReason = "createAnswer failed: " + e; onMediaFailed(); }
            @Override public void onSetFailure(String e) {}
        }, new MediaConstraints());
    }

    /**
     * SdpObserver for setRemoteDescription: marks the remote description
     * as set, flushes queued ICE candidates, then runs onSuccess (used
     * by the callee to create the answer).
     */
    private SdpObserver sdpObserverForRemote(final Runnable onSuccess) {
        return new SdpObserver() {
            @Override public void onCreateSuccess(SessionDescription s) {}
            @Override public void onSetSuccess() {
                mainHandler.post(() -> {
                    remoteDescriptionSet = true;
                    if (pc != null && !ended) {
                        for (IceCandidate c : pendingCandidates) {
                            try { pc.addIceCandidate(c); } catch (Throwable ignored) {}
                        }
                    }
                    pendingCandidates.clear();
                    if (onSuccess != null) onSuccess.run();
                });
            }
            @Override public void onCreateFailure(String e) {}
            @Override public void onSetFailure(String e) { lastFailureReason = "setRemoteDescription failed: " + e; onMediaFailed(); }
        };
    }

    private SdpObserver sdpObserverForRemote() {
        return sdpObserverForRemote(null);
    }

    private void startCamera() throws Exception {
        VideoCapturer capturer = createCameraCapturer();
        if (capturer == null) throw new IllegalStateException("no camera found");
        videoCapturer = capturer;
        surfaceTextureHelper = SurfaceTextureHelper.create("CaptureThread", eglBase.getEglBaseContext());
        videoSource = factory.createVideoSource(false);
        videoCapturer.initialize(surfaceTextureHelper, appContext, videoSource.getCapturerObserver());
        localVideoTrack = factory.createVideoTrack("ARDAMSv0", videoSource);
        pc.addTrack(localVideoTrack, Arrays.asList("ARDAMS"));
        videoCapturer.startCapture(640, 480, 30);
        if (localRenderer != null) {
            try { localVideoTrack.addSink(localRenderer); } catch (Throwable ignored) {}
        }
    }

    private VideoCapturer createCameraCapturer() {
        CameraVideoCapturer.CameraEventsHandler events = new CameraVideoCapturer.CameraEventsHandler() {
            @Override public void onCameraError(String e) { Log.w(TAG, "camera error: " + e); }
            @Override public void onCameraDisconnected() {}
            @Override public void onCameraFreezed(String e) {}
            @Override public void onCameraOpening(String id) {}
            @Override public void onFirstFrameAvailable() {}
            @Override public void onCameraClosed() {}
        };
        if (Camera2Enumerator.isSupported(appContext)) {
            Camera2Enumerator enumerator = new Camera2Enumerator(appContext);
            for (String name : enumerator.getDeviceNames()) {
                if (enumerator.isFrontFacing(name)) {
                    return enumerator.createCapturer(name, events);
                }
            }
            String[] names = enumerator.getDeviceNames();
            if (names.length > 0) return enumerator.createCapturer(names[0], events);
        }
        Camera1Enumerator enumerator = new Camera1Enumerator(true);
        for (String name : enumerator.getDeviceNames()) {
            if (enumerator.isFrontFacing(name)) {
                return enumerator.createCapturer(name, events);
            }
        }
        String[] names = enumerator.getDeviceNames();
        if (names.length > 0) return enumerator.createCapturer(names[0], events);
        return null;
    }

    private void launchCallActivity() {
        Intent i = new Intent(appContext, CallActivity.class);
        i.putExtra("callId", callId);
        i.putExtra("type", callType);
        i.putExtra("name", partnerName);
        i.putExtra("emoji", partnerEmoji);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        appContext.startActivity(i);
        traceCall("activity startActivity returned");
    }

    // ===== Teardown (main thread) =====

    private void endCallOnMain() {
        traceCall("ended");
        try {
            if (ended) {
                finishActivity();
                return;
            }
            ended = true;
            cleanupMedia();
            fireEvent("ended", null);
            finishActivity();
            if (uiListener != null) uiListener.onEnded();
            // Restore normal audio routing a moment later, once the WebRTC
            // audio device has wound down.
            mainHandler.postDelayed(() -> {
                try {
                    AudioManager am = (AudioManager) appContext.getSystemService(Context.AUDIO_SERVICE);
                    if (am != null) {
                        am.setMode(AudioManager.MODE_NORMAL);
                        am.setSpeakerphoneOn(false);
                    }
                } catch (Throwable ignored) {}
            }, 500);
        } catch (Throwable t) {
            Log.w(TAG, "endCall failed", t);
            try { finishActivity(); } catch (Throwable ignored) {}
        }
    }

    private void finishActivity() {
        if (callActivity != null) {
            final CallActivity a = callActivity;
            callActivity = null;
            try { a.finish(); } catch (Throwable ignored) {}
        }
    }

    private void cleanupMedia() {
        if (pc != null) {
            try { pc.close(); } catch (Throwable ignored) {}
            try { pc.dispose(); } catch (Throwable ignored) {}
            pc = null;
        }
        if (videoCapturer != null) {
            try { videoCapturer.stopCapture(); } catch (Throwable ignored) {}
            try { videoCapturer.dispose(); } catch (Throwable ignored) {}
            videoCapturer = null;
        }
        if (videoSource != null) {
            try { videoSource.dispose(); } catch (Throwable ignored) {}
            videoSource = null;
        }
        if (surfaceTextureHelper != null) {
            try { surfaceTextureHelper.dispose(); } catch (Throwable ignored) {}
            surfaceTextureHelper = null;
        }
        if (localVideoTrack != null) {
            try { localVideoTrack.dispose(); } catch (Throwable ignored) {}
            localVideoTrack = null;
        }
        if (localAudioTrack != null) {
            try { localAudioTrack.dispose(); } catch (Throwable ignored) {}
            localAudioTrack = null;
        }
        if (audioSource != null) {
            try { audioSource.dispose(); } catch (Throwable ignored) {}
            audioSource = null;
        }
        remoteVideoTrack = null;
        pendingCandidates.clear();
        remoteDescriptionSet = false;
    }

    // ===== Call-failure reporting (v1.11) =====
    // The user only ever saw a generic "Call failed" toast, so the real
    // error was lost. Save the exact reason in the same store the
    // Settings > About "Last crash" row reads, and send it to JS too.

    private void saveCallFailureReport(String headline, Throwable t) {
        try {
            StringBuilder sb = new StringBuilder();
            sb.append("Call failed: ").append(headline != null ? headline : "unknown");
            sb.append("\n(").append(new java.util.Date().toString()).append(")");
            StackTraceElement[] frames = t != null
                    ? t.getStackTrace()
                    : Thread.currentThread().getStackTrace();
            int start = (t != null) ? 0 : 3; // skip getStackTrace + this helper
            int n = Math.min(frames.length, start + 8);
            for (int i = start; i < n; i++) {
                sb.append("\n").append(frames[i].toString());
            }
            // v1.15: commit() (synchronous) — same reason as saveLastCrash
            // in MainActivity: an async apply() can be lost on process death.
            appContext.getSharedPreferences("moon_crash", android.content.Context.MODE_PRIVATE)
                    .edit().putString("last_crash", sb.toString()).commit();
        } catch (Throwable ignored) {}
    }

    private void reportCallFailure(String reason, Throwable t) {
        try {
            String r = reason != null ? reason : "unknown error";
            traceCall("failed: " + r);
            saveCallFailureReport(r, t);
            JSONObject extra = new JSONObject();
            extra.put("reason", r);
            fireEvent("failed", extra);
        } catch (Throwable ignored) {
            try { fireEvent("failed", null); } catch (Throwable ignored2) {}
        }
    }

    private void onMediaFailed() {
        mainHandler.post(() -> {
            if (ended) return;
            String reason = lastFailureReason != null ? lastFailureReason : "media failed";
            reportCallFailure(reason, null);
            if (uiListener != null) uiListener.onFailed();
            // Safety net: make sure the call is torn down even if the
            // web app does not answer the failure event.
            mainHandler.postDelayed(this::endCallOnMain, 500);
        });
    }

    // ===== Factory =====

    private void ensureFactory() {
        if (factory != null) return;
        try {
            PeerConnectionFactory.initialize(
                    PeerConnectionFactory.InitializationOptions.builder(appContext)
                            .createInitializationOptions());
            eglBase = EglBase.create();
            // v1.14: hardware AEC/NS OFF — software processing instead.
            // Hardware acoustic echo cancellation / noise suppression is
            // a suspected native-crash source on this (MediaTek/Helio)
            // phone: the native audio device starts right when the call
            // screen opens, which is exactly when the app dies.
            // v1.16: capture with the plain MIC audio source. The ADM
            // builder's DEFAULT audio source is VOICE_COMMUNICATION —
            // the HAL voice-processing path — and the v1.15 trace showed
            // the process dies right after setLocalDescription, before
            // CallActivity.onCreate even starts and before any ICE
            // callback fires, i.e. in the native media engine as the
            // audio device opens. This phone's WebView mic already
            // failed with NotReadableError (v1.3–v1.5), while the native
            // MediaRecorder — which uses the MIC source — records fine
            // (v1.6), so MIC is the proven-working capture path here.
            JavaAudioDeviceModule adm = JavaAudioDeviceModule.builder(appContext)
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setUseHardwareAcousticEchoCanceler(false)
                    .setUseHardwareNoiseSuppressor(false)
                    .createAudioDeviceModule();
            factory = PeerConnectionFactory.builder()
                    .setAudioDeviceModule(adm)
                    .setVideoEncoderFactory(new DefaultVideoEncoderFactory(
                            eglBase.getEglBaseContext(), true, true))
                    .setVideoDecoderFactory(new DefaultVideoDecoderFactory(
                            eglBase.getEglBaseContext()))
                    .createPeerConnectionFactory();
        } catch (Throwable t) {
            // Half-built factory must never be reused: drop it (and any
            // half-built EGL base) so the next call attempt starts clean,
            // then rethrow for the call-path catches to turn into a
            // "call failed" message instead of a crash.
            factory = null;
            if (eglBase != null) {
                try { eglBase.release(); } catch (Throwable ignored) {}
                eglBase = null;
            }
            Log.w(TAG, "ensureFactory failed", t);
            if (t instanceof Error) throw (Error) t;
            if (t instanceof RuntimeException) throw (RuntimeException) t;
            throw new IllegalStateException("WebRTC factory init failed", t);
        }
    }

    private void applySpeakerphone() {
        try {
            AudioManager am = (AudioManager) appContext.getSystemService(Context.AUDIO_SERVICE);
            if (am != null) {
                am.setMode(AudioManager.MODE_IN_COMMUNICATION);
                am.setSpeakerphoneOn(speakerOn);
            }
        } catch (Throwable ignored) {}
    }

    // ===== Signaling helpers =====

    private List<PeerConnection.IceServer> parseIceServers(String iceJson) throws Exception {
        List<PeerConnection.IceServer> servers = new ArrayList<>();
        JSONArray arr = new JSONArray(iceJson);
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.getJSONObject(i);
            List<String> urls = new ArrayList<>();
            Object u = o.get("urls");
            if (u instanceof JSONArray) {
                JSONArray ua = (JSONArray) u;
                for (int j = 0; j < ua.length(); j++) urls.add(ua.getString(j));
            } else {
                urls.add(o.getString("urls"));
            }
            PeerConnection.IceServer.Builder b = PeerConnection.IceServer.builder(urls);
            if (o.has("username")) b.setUsername(o.optString("username"));
            if (o.has("credential")) b.setPassword(o.optString("credential"));
            servers.add(b.createIceServer());
        }
        return servers;
    }

    private void fireLocalDescription(String type, SessionDescription sdp) {
        traceCall("localDescription set");
        try {
            JSONObject s = new JSONObject();
            s.put("type", type);
            s.put("sdp", sdp.description);
            JSONObject ev = new JSONObject();
            ev.put("type", "localDescription");
            ev.put("sdp", s);
            fireEvent(ev);
        } catch (Throwable ignored) {}
    }

    private void fireEvent(String type, JSONObject extra) {
        try {
            JSONObject ev = new JSONObject();
            ev.put("type", type);
            if (extra != null) {
                java.util.Iterator<String> keys = extra.keys();
                while (keys.hasNext()) {
                    String k = keys.next();
                    ev.put(k, extra.get(k));
                }
            }
            fireEvent(ev);
        } catch (Throwable ignored) {}
    }

    private void fireEvent(JSONObject ev) {
        if (eventListener == null) return;
        final String json = ev.toString();
        eventListener.onCallEvent(json);
    }

    private final PeerConnection.Observer pcObserver = new PeerConnection.Observer() {
        @Override public void onSignalingChange(PeerConnection.SignalingState s) {}
        // v1.15: trace ICE state changes — if the app dies in the native
        // PeerConnection threads right after localDescription is set,
        // these lines show how far the native side got.
        @Override public void onIceConnectionChange(PeerConnection.IceConnectionState s) {
            traceCall("ice connection: " + s);
        }
        @Override public void onIceConnectionReceivingChange(boolean b) {}
        @Override public void onIceGatheringChange(PeerConnection.IceGatheringState s) {
            traceCall("ice gathering: " + s);
        }
        @Override public void onIceCandidate(final IceCandidate cand) {
            mainHandler.post(() -> {
                try {
                    JSONObject c = new JSONObject();
                    c.put("candidate", cand.sdp);
                    c.put("sdpMid", cand.sdpMid);
                    c.put("sdpMLineIndex", cand.sdpMLineIndex);
                    JSONObject ev = new JSONObject();
                    ev.put("type", "iceCandidate");
                    ev.put("candidate", c);
                    fireEvent(ev);
                } catch (Throwable ignored) {}
            });
        }
        @Override public void onIceCandidatesRemoved(IceCandidate[] c) {}
        @Override public void onAddStream(MediaStream stream) {
            mainHandler.post(() -> {
                if (stream.videoTracks != null && !stream.videoTracks.isEmpty()) {
                    attachRemoteVideo(stream.videoTracks.get(0));
                }
            });
        }
        @Override public void onRemoveStream(MediaStream stream) {}
        @Override public void onDataChannel(DataChannel dc) {}
        @Override public void onRenegotiationNeeded() {}
        @Override public void onAddTrack(RtpReceiver receiver, MediaStream[] streams) {
            mainHandler.post(() -> {
                traceCall("remote track: " + (receiver != null && receiver.track() != null
                        ? receiver.track().kind() : "?"));
                if (receiver != null && receiver.track() instanceof VideoTrack) {
                    attachRemoteVideo((VideoTrack) receiver.track());
                }
            });
        }
        @Override public void onConnectionChange(PeerConnection.PeerConnectionState state) {
            mainHandler.post(() -> {
                if (ended) return;
                if (state == PeerConnection.PeerConnectionState.CONNECTED) {
                    if (!connected) {
                        connected = true;
                        traceCall("connected");
                        applySpeakerphone();
                        fireEvent("connected", null);
                        if (uiListener != null) uiListener.onConnected();
                    }
                } else if (state == PeerConnection.PeerConnectionState.FAILED) {
                    lastFailureReason = "PeerConnection failed (ICE/connectivity)";
                    onMediaFailed();
                }
            });
        }
    };

    private void attachRemoteVideo(VideoTrack track) {
        remoteVideoTrack = track;
        if (remoteRenderer != null) {
            try { track.addSink(remoteRenderer); } catch (Throwable ignored) {}
        }
    }
}
