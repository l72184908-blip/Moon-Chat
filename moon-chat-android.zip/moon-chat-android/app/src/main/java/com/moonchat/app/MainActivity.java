package com.moonchat.app;

import android.net.Uri;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private ActivityResultLauncher<String> pickImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // REAL screenshot / screen-recording protection.
        // FLAG_SECURE blocks screenshots and screen recording on Android,
        // and hides the app content in the recent-apps switcher.
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
        );

        // Photo picker for <input type="file"> inside the WebView.
        // A WebView does NOT open the gallery on its own: without
        // onShowFileChooser, tapping "Choose photo" does nothing.
        // GetContent opens the system photo picker and needs no
        // storage permission on modern Android.
        pickImage = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(uri != null ? new Uri[]{uri} : null);
                filePathCallback = null;
            }
        });

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                pickImage.launch("image/*");
                return true;
            }
        });

        // Load the bundled Moon Chat web app (works offline, no server needed).
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
