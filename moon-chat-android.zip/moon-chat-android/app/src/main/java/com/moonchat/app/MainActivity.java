package com.moonchat.app;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    // File chooser for <input type="file"> (photos): offers BOTH the
    // camera (take a new photo) and the gallery (pick an existing one).
    private ActivityResultLauncher<Intent> fileChooser;
    // URI of a photo the camera app is writing (returned when the
    // chooser result has no data URI of its own).
    private Uri cameraPhotoUri;
    // A WebView permission request waiting on the Android permission dialog
    // (e.g. mic/camera tap while the app permission is not held yet).
    private PermissionRequest pendingPermRequest;
    private List<String> pendingPermResources;

    // Native voice recording (bypasses WebView getUserMedia, which fails
    // with NotReadableError on some devices even when the mic permission
    // is granted). The web page calls MoonVoice.startVoice()/stopVoice().
    private MediaRecorder voiceRecorder;
    private File voiceFile;
    private long voiceStartMs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Crash diagnostics (v1.10): if the app crashes again — e.g. the
        // native call engine failing on this phone — save the exception
        // (name + message + top stack frames) so the next launch can show
        // it in Settings → About and the user can report the real error.
        // The previous handler still runs, so the app closes normally.
        installCrashHandler();
        // If the previous run crashed, tell the user right away.
        String lastCrash = readLastCrash();
        if (lastCrash != null && !lastCrash.isEmpty()) {
            String firstLine = lastCrash.split("\n", 2)[0];
            Toast.makeText(this, "Last crash: " + firstLine, Toast.LENGTH_LONG).show();
        }

        // REAL screenshot / screen-recording protection.
        // FLAG_SECURE blocks screenshots and screen recording on Android,
        // and hides the app content in the recent-apps switcher.
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
        );

        // Microphone + camera permissions for voice messages and photos.
        // Requested once at launch so the WebView mic grant below can work.
        List<String> launchPerms = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            launchPerms.add(Manifest.permission.RECORD_AUDIO);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            launchPerms.add(Manifest.permission.CAMERA);
        }
        if (!launchPerms.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                    launchPerms.toArray(new String[0]), 1001);
        }

        // Photo picker for <input type="file"> inside the WebView.
        // A WebView does NOT open the gallery on its own: without
        // onShowFileChooser, tapping "Choose photo" does nothing.
        // The chooser offers BOTH the camera (take a new photo) and the
        // gallery (pick an existing one). Camera photos are written to a
        // FileProvider URI in the cache dir (no storage permission needed).
        fileChooser = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            Uri[] results = null;
            if (result.getResultCode() == RESULT_OK) {
                Intent data = result.getData();
                if (data != null && data.getData() != null) {
                    results = new Uri[]{data.getData()};
                } else if (cameraPhotoUri != null) {
                    // Camera capture returns no data URI — the photo is
                    // the file we asked the camera app to write.
                    results = new Uri[]{cameraPhotoUri};
                }
            }
            cameraPhotoUri = null;
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        });

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        // Native voice recorder bridge for the web app.
        webView.addJavascriptInterface(new VoiceBridge(), "MoonVoice");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                // Gallery intent + camera intent in one chooser (photos only).
                Intent gallery = new Intent(Intent.ACTION_GET_CONTENT);
                gallery.addCategory(Intent.CATEGORY_OPENABLE);
                gallery.setType("image/*");
                Intent camera = null;
                cameraPhotoUri = null;
                try {
                    File photoFile = createImageFile();
                    cameraPhotoUri = FileProvider.getUriForFile(MainActivity.this,
                            getPackageName() + ".fileprovider", photoFile);
                    camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraPhotoUri);
                    camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                } catch (Exception ignored) { camera = null; cameraPhotoUri = null; }
                Intent chooser = Intent.createChooser(gallery, "Choose a photo");
                if (camera != null) {
                    chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Parcelable[]{camera});
                }
                fileChooser.launch(chooser);
                return true;
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                // Voice messages: the web page asks for the mic via
                // getUserMedia (web fallback when the native recorder is
                // unavailable). A WebView denies it unless the app grants
                // it here.
                // If the app does not hold the matching Android permission
                // yet, ask the user RIGHT NOW (while they are tapping the
                // mic/camera button) and grant/deny the WebView request once
                // they answer — instead of denying silently, which left
                // voice messages broken after a single earlier denial.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    List<String> wanted = new ArrayList<>();
                    List<String> missing = new ArrayList<>();
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) {
                            wanted.add(r);
                            if (ContextCompat.checkSelfPermission(MainActivity.this,
                                    Manifest.permission.RECORD_AUDIO)
                                    != PackageManager.PERMISSION_GRANTED) {
                                missing.add(Manifest.permission.RECORD_AUDIO);
                            }
                        } else if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(r)) {
                            wanted.add(r);
                            if (ContextCompat.checkSelfPermission(MainActivity.this,
                                    Manifest.permission.CAMERA)
                                    != PackageManager.PERMISSION_GRANTED) {
                                missing.add(Manifest.permission.CAMERA);
                            }
                        }
                    }
                    if (wanted.isEmpty()) { request.deny(); return; }
                    if (missing.isEmpty()) {
                        request.grant(wanted.toArray(new String[0]));
                    } else {
                        pendingPermRequest = request;
                        pendingPermResources = wanted;
                        ActivityCompat.requestPermissions(MainActivity.this,
                                missing.toArray(new String[0]), 1002);
                    }
                }
            }
        });

        // Load the bundled Moon Chat web app (works offline, no server needed).
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Answer a mic/camera tap that was waiting on the permission dialog.
        // Grant only the WebView resources whose Android permission was
        // actually granted; deny the request if none was granted.
        if (requestCode == 1002 && pendingPermRequest != null) {
            List<String> grantedRes = new ArrayList<>();
            for (int i = 0; i < permissions.length; i++) {
                if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                    if (Manifest.permission.RECORD_AUDIO.equals(permissions[i])) {
                        grantedRes.add(PermissionRequest.RESOURCE_AUDIO_CAPTURE);
                    } else if (Manifest.permission.CAMERA.equals(permissions[i])) {
                        grantedRes.add(PermissionRequest.RESOURCE_VIDEO_CAPTURE);
                    }
                }
            }
            if (pendingPermResources != null) grantedRes.retainAll(pendingPermResources);
            if (!grantedRes.isEmpty()) {
                pendingPermRequest.grant(grantedRes.toArray(new String[0]));
            } else {
                pendingPermRequest.deny();
            }
            pendingPermRequest = null;
            pendingPermResources = null;
        }
    }

    @Override
    protected void onDestroy() {
        releaseVoiceRecorder();
        super.onDestroy();
    }

    // ===== Crash diagnostics (v1.10) =====

    private void installCrashHandler() {
        Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                saveLastCrash(throwable);
            } catch (Throwable ignored) {}
            if (prev != null) prev.uncaughtException(thread, throwable);
        });
    }

    private void saveLastCrash(Throwable t) {
        StringBuilder sb = new StringBuilder();
        sb.append(t.getClass().getSimpleName());
        String msg = t.getMessage();
        sb.append(": ").append(msg != null ? msg : "");
        sb.append("\n(").append(new java.util.Date().toString()).append(")");
        StackTraceElement[] frames = t.getStackTrace();
        int n = Math.min(frames.length, 15);
        for (int i = 0; i < n; i++) {
            sb.append("\n").append(frames[i].toString());
        }
        // v1.15: commit() (synchronous), not apply() — the old async
        // write could be lost when the process dies from the crash,
        // which is very likely why "Last crash" showed nothing on v1.13.
        getSharedPreferences("moon_crash", MODE_PRIVATE)
                .edit().putString("last_crash", sb.toString()).commit();
    }

    private String readLastCrash() {
        SharedPreferences prefs = getSharedPreferences("moon_crash", MODE_PRIVATE);
        return prefs.getString("last_crash", null);
    }

    // Temp file for a photo taken with the camera (served to the camera
    // app through FileProvider; lives in the cache dir).
    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        File dir = new File(getCacheDir(), "camera");
        if (!dir.exists()) dir.mkdirs();
        return File.createTempFile("IMG_" + timeStamp + "_", ".jpg", dir);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    // ===== Native voice recording =====

    private class VoiceBridge {
        @JavascriptInterface
        public boolean isNativeVoice() { return true; }

        // Returns "ok", "no-permission" or "busy".
        @JavascriptInterface
        public String startVoice() {
            if (ContextCompat.checkSelfPermission(MainActivity.this,
                    Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                return "no-permission";
            }
            // MediaRecorder calls run on the UI thread; the JS bridge thread
            // waits briefly for the result.
            final String[] result = new String[1];
            final CountDownLatch latch = new CountDownLatch(1);
            runOnUiThread(() -> {
                result[0] = startVoiceOnUi();
                latch.countDown();
            });
            try {
                if (!latch.await(5, TimeUnit.SECONDS)) return "busy";
            } catch (InterruptedException e) {
                return "busy";
            }
            return result[0] != null ? result[0] : "busy";
        }

        @JavascriptInterface
        public void stopVoice(boolean send) {
            runOnUiThread(() -> stopVoiceRecorder(send));
        }
    }

    private String startVoiceOnUi() {
        releaseVoiceRecorder();
        try {
            voiceFile = new File(getCacheDir(), "voice_" + System.currentTimeMillis() + ".m4a");
            MediaRecorder r = new MediaRecorder();
            r.setAudioSource(MediaRecorder.AudioSource.MIC);
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            r.setAudioEncodingBitRate(32000);
            r.setAudioSamplingRate(44100);
            r.setAudioChannels(1);
            r.setOutputFile(voiceFile.getAbsolutePath());
            r.setMaxDuration(60000);
            r.prepare();
            r.start();
            voiceRecorder = r;
            voiceStartMs = System.currentTimeMillis();
            return "ok";
        } catch (Exception e) {
            releaseVoiceRecorder();
            return "busy";
        }
    }

    private void stopVoiceRecorder(boolean send) {
        MediaRecorder r = voiceRecorder;
        voiceRecorder = null;
        File f = voiceFile;
        voiceFile = null;
        if (r != null) {
            try { r.stop(); } catch (Exception ignored) {}
            try { r.release(); } catch (Exception ignored) {}
        }
        if (!send || f == null || !f.exists()) {
            if (f != null) f.delete();
            return;
        }
        long dur = Math.max(1, (System.currentTimeMillis() - voiceStartMs) / 1000);
        try {
            byte[] bytes = java.nio.file.Files.readAllBytes(f.toPath());
            String b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP);
            f.delete();
            final String js = "window.onNativeVoice('data:audio/mp4;base64," + b64 + "'," + dur + ")";
            webView.post(() -> webView.evaluateJavascript(js, null));
        } catch (Exception e) {
            webView.post(() -> webView.evaluateJavascript(
                    "window.onNativeVoiceError && window.onNativeVoiceError('send failed')", null));
        }
    }

    private void releaseVoiceRecorder() {
        MediaRecorder r = voiceRecorder;
        voiceRecorder = null;
        if (r != null) {
            try { r.release(); } catch (Exception ignored) {}
        }
        if (voiceFile != null) {
            voiceFile.delete();
            voiceFile = null;
        }
    }
}
