package com.moonchat.app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private ActivityResultLauncher<String> pickImage;
    private PermissionRequest pendingMicRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // REAL screenshot / screen-recording protection.
        // FLAG_SECURE blocks screenshots and screen recording on Android,
        // and hides the app content in the recent-apps switcher.
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
        );

        // Microphone permission for voice messages (MediaRecorder in the WebView).
        // Requested once at launch so the WebView mic grant below can work.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO}, 1001);
        }

        // Photo picker for <input type="file"> inside the WebView.
        // A WebView does NOT open the gallery on its own: without
        // onShowFileChooser, tapping "Choose photo" does nothing.
        // GetContent opens the system photo picker and needs no
        // storage permission on modern Android.
        pickImage = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(uri != null ? new Uri[]{uri} : null);
                filePathCallback = null;
            }
        });

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                pickImage.launch("image/*");
                return true;
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                // Voice recording: the web page asks for the mic via getUserMedia.
                // A WebView denies it unless the app grants it here.
                // If the app does not hold RECORD_AUDIO yet, ask the user
                // RIGHT NOW (while they are tapping the mic button) and
                // grant/deny the WebView request once they answer — instead
                // of denying silently, which left voice messages broken
                // after a single earlier denial at launch.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    List<String> wanted = new ArrayList<>();
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) wanted.add(r);
                    }
                    if (wanted.isEmpty()) { request.deny(); return; }
                    if (ContextCompat.checkSelfPermission(MainActivity.this,
                            Manifest.permission.RECORD_AUDIO)
                            == PackageManager.PERMISSION_GRANTED) {
                        request.grant(wanted.toArray(new String[0]));
                    } else {
                        pendingMicRequest = request;
                        ActivityCompat.requestPermissions(MainActivity.this,
                                new String[]{Manifest.permission.RECORD_AUDIO}, 1002);
                    }
                }
            }
        });

        // Load the bundled Moon Chat web app (works offline, no server needed).
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Answer a mic tap that was waiting on the permission dialog.
        if (requestCode == 1002 && pendingMicRequest != null) {
            boolean granted = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                pendingMicRequest.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            } else {
                pendingMicRequest.deny();
            }
            pendingMicRequest = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
