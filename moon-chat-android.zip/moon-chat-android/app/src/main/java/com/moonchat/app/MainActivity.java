package com.moonchat.app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private ActivityResultLauncher<String> pickImage;
    private PermissionRequest pendingMicRequest;

    // Native voice recording (bypasses WebView getUserMedia, which fails
    // with NotReadableError on some devices even when the mic permission
    // is granted). The web page calls MoonVoice.startVoice()/stopVoice().
    private MediaRecorder voiceRecorder;
    private File voiceFile;
    private long voiceStartMs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // REAL screenshot / screen-recording protection.
        // FLAG_SECURE blocks screenshots and screen recording on Android,
        // and hides the app content in the recent-apps switcher.
        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE
        );

        // Microphone permission for voice messages.
        // Requested once at launch so the WebView mic grant below can work.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.RECORD_AUDIO}, 1001);
        }

        // Photo picker for <input type="file"> inside the WebView.
        // A WebView does NOT open the gallery on its own: without
        // onShowFileChooser, tapping "Choose photo" does nothing.
        // GetContent opens the system photo picker and needs no
        // storage permission on modern Android.
        pickImage = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(uri != null ? new Uri[]{uri} : null);
                filePathCallback = null;
            }
        });

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);

        // Native voice recorder bridge for the web app.
        webView.addJavascriptInterface(new VoiceBridge(), "MoonVoice");

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                pickImage.launch("image/*");
                return true;
            }

            @Override
            public void onPermissionRequest(PermissionRequest request) {
                // Voice recording: the web page asks for the mic via getUserMedia.
                // A WebView denies it unless the app grants it here.
                // If the app does not hold RECORD_AUDIO yet, ask the user
                // RIGHT NOW (while they are tapping the mic button) and
                // grant/deny the WebView request once they answer — instead
                // of denying silently, which left voice messages broken
                // after a single earlier denial at launch.
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    List<String> wanted = new ArrayList<>();
                    for (String r : request.getResources()) {
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(r)) wanted.add(r);
                    }
                    if (wanted.isEmpty()) { request.deny(); return; }
                    if (ContextCompat.checkSelfPermission(MainActivity.this,
                            Manifest.permission.RECORD_AUDIO)
                            == PackageManager.PERMISSION_GRANTED) {
                        request.grant(wanted.toArray(new String[0]));
                    } else {
                        pendingMicRequest = request;
                        ActivityCompat.requestPermissions(MainActivity.this,
                                new String[]{Manifest.permission.RECORD_AUDIO}, 1002);
                    }
                }
            }
        });

        // Load the bundled Moon Chat web app (works offline, no server needed).
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Answer a mic tap that was waiting on the permission dialog.
        if (requestCode == 1002 && pendingMicRequest != null) {
            boolean granted = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                pendingMicRequest.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            } else {
                pendingMicRequest.deny();
            }
            pendingMicRequest = null;
        }
    }

    @Override
    protected void onDestroy() {
        releaseVoiceRecorder();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    // ===== Native voice recording =====

    private class VoiceBridge {
        @JavascriptInterface
        public boolean isNativeVoice() { return true; }

        // Returns "ok", "no-permission" or "busy".
        @JavascriptInterface
        public String startVoice() {
            if (ContextCompat.checkSelfPermission(MainActivity.this,
                    Manifest.permission.RECORD_AUDIO)
                    != PackageManager.PERMISSION_GRANTED) {
                return "no-permission";
            }
            // MediaRecorder calls run on the UI thread; the JS bridge thread
            // waits briefly for the result.
            final String[] result = new String[1];
            final CountDownLatch latch = new CountDownLatch(1);
            runOnUiThread(() -> {
                result[0] = startVoiceOnUi();
                latch.countDown();
            });
            try {
                if (!latch.await(5, TimeUnit.SECONDS)) return "busy";
            } catch (InterruptedException e) {
                return "busy";
            }
            return result[0] != null ? result[0] : "busy";
        }

        @JavascriptInterface
        public void stopVoice(boolean send) {
            runOnUiThread(() -> stopVoiceRecorder(send));
        }
    }

    private String startVoiceOnUi() {
        releaseVoiceRecorder();
        try {
            voiceFile = new File(getCacheDir(), "voice_" + System.currentTimeMillis() + ".m4a");
            MediaRecorder r = new MediaRecorder();
            r.setAudioSource(MediaRecorder.AudioSource.MIC);
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            r.setAudioEncodingBitRate(32000);
            r.setAudioSamplingRate(44100);
            r.setAudioChannels(1);
            r.setOutputFile(voiceFile.getAbsolutePath());
            r.setMaxDuration(60000);
            r.prepare();
            r.start();
            voiceRecorder = r;
            voiceStartMs = System.currentTimeMillis();
            return "ok";
        } catch (Exception e) {
            releaseVoiceRecorder();
            return "busy";
        }
    }

    private void stopVoiceRecorder(boolean send) {
        MediaRecorder r = voiceRecorder;
        voiceRecorder = null;
        File f = voiceFile;
        voiceFile = null;
        if (r != null) {
            try { r.stop(); } catch (Exception ignored) {}
            try { r.release(); } catch (Exception ignored) {}
        }
        if (!send || f == null || !f.exists()) {
            if (f != null) f.delete();
            return;
        }
        long dur = Math.max(1, (System.currentTimeMillis() - voiceStartMs) / 1000);
        try {
            byte[] bytes = java.nio.file.Files.readAllBytes(f.toPath());
            String b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP);
            f.delete();
            final String js = "window.onNativeVoice('data:audio/mp4;base64," + b64 + "'," + dur + ")";
            webView.post(() -> webView.evaluateJavascript(js, null));
        } catch (Exception e) {
            webView.post(() -> webView.evaluateJavascript(
                    "window.onNativeVoiceError && window.onNativeVoiceError('send failed')", null));
        }
    }

    private void releaseVoiceRecorder() {
        MediaRecorder r = voiceRecorder;
        voiceRecorder = null;
        if (r != null) {
            try { r.release(); } catch (Exception ignored) {}
        }
        if (voiceFile != null) {
            voiceFile.delete();
            voiceFile = null;
        }
    }
}
