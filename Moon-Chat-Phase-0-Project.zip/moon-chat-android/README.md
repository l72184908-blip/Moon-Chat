# Moon Chat — Android project

This ZIP is the initial Android client prototype, not yet a production messaging service.

- Package: `com.moonchat.app`
- Android host: Java + WebView
- Current UI: `app/src/main/assets/www/index.html`
- Current storage: local device `localStorage` (demo only)
- Android screenshot protection: `FLAG_SECURE` in `MainActivity.java`

## Current limitations
The supplied UI includes hard-coded demo contacts/replies and local-only chat storage. It does not yet provide real user-to-user messaging, server-side six-digit ID allocation, image upload, end-to-end encryption, or Recovery Key account restoration. Do not use it for private or sensitive conversations.

## Build a debug APK in the cloud
A GitHub Actions workflow is included at `.github/workflows/android-apk.yml`. Upload this project to a GitHub repository, then open **Actions → Build Moon Chat APK → Run workflow**. The resulting APK is published as an Actions artifact. This workflow builds the current prototype only; it does not add backend functionality.

## Build locally
Requires Java 17, Android SDK 34, and Gradle 8.7:

```bash
gradle assembleDebug
```

## Next development phase
See `DEVELOPMENT_STATUS.md` and `FIREBASE_SETUP_NEXT.md`. Firebase project configuration is required before connecting the client to a real backend. A maintained E2EE protocol must be integrated and security-reviewed; do not implement custom cryptography.
