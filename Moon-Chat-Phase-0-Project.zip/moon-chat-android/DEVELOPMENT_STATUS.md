# Moon Chat — Development Status (Phase 0)

## Source audit
The supplied project is a Java Android host with a WebView UI (`app/src/main/assets/www/index.html`). The current UI stores profiles and chats in browser `localStorage`, includes hard-coded demo contacts/replies, and does not implement a network messaging backend or end-to-end encryption. `MainActivity` sets Android `FLAG_SECURE`, which is useful screenshot/screen-recording protection on supported Android builds, but cannot stop external-camera capture.

## Phase 0 changes in this package
- Replaced missing `@mipmap` launcher icon references with an included vector Moon Chat icon, fixing a known resource-resolution problem.
- Added a GitHub Actions workflow to build a debug APK in the cloud (Java 17, Gradle 8.7). This is a build path, not a backend.
- Kept the existing demo behavior clearly separate from production functionality.

## Production architecture decision
- Android client: native Android app; keep `FLAG_SECURE` enabled on private screens.
- Backend: Firebase Authentication (anonymous bootstrap), Cloud Firestore (message metadata and delivery), Cloud Storage (encrypted image blobs), Cloud Functions (ID allocation, recovery, membership checks, rate limits, cleanup).
- Identity: generate a high-entropy Recovery Key on-device. The six-digit Moon ID is a public discovery handle only; it is never an authentication secret.
- Recovery: a backend-verified recovery flow must exchange a cryptographic proof derived from the Recovery Key for a Firebase custom token. Never store the raw Recovery Key on the server.
- Encryption: use a maintained, independently reviewed end-to-end encryption protocol/library. Do not invent a cryptographic protocol or claim E2EE until key verification, session setup, message encryption, image encryption, rotation, multi-device behavior, and recovery have been implemented and tested.

## Required before real backend integration
1. Create a Firebase project and register an Android app with package `com.moonchat.app`.
2. Download that project's `google-services.json` and place it in `app/`. Do not share service-account private keys or admin credentials.
3. Enable the required Firebase products and configure restrictive Firestore/Storage rules before testing with real users.
4. Decide how users verify contacts and recover accounts. Recovery Key loss means account recovery may be impossible by design.

## Important limitations
- `FLAG_SECURE` is not absolute privacy; another device can photograph the screen.
- Six-digit IDs have a small search space and require server-side throttling, abuse controls, and possibly user approval before accepting a chat.
- A debug APK is for testing only; public release requires a signed release build, privacy policy, abuse reporting/blocking, secure rules, and security review.
