# Firebase setup needed for Phase 1

1. Open https://console.firebase.google.com/ in a browser and sign in with a Google account.
2. Create a project named `Moon Chat` (Analytics can be disabled for the first prototype).
3. Add an Android app with package name `com.moonchat.app`.
4. Download `google-services.json`. It is a client configuration file; never download or share a service-account private key.
5. In Firebase Console, enable Authentication, Cloud Firestore, Cloud Storage, and Cloud Functions as the implementation requires.
6. Keep Firestore and Storage in locked/production mode; do not use open rules such as `allow read, write: if true`.

The downloaded `google-services.json` is needed before the Android client can be connected to your own Firebase project. Do not post passwords or private service-account keys in chat.
