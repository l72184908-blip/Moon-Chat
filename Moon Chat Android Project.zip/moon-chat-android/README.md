# Moon Chat — Android Project
## What this is

A ready-to-open Android project for Moon Chat, the private & secure messaging app.

- **Package:** `com.moonchat.app`
- **App name:** Moon Chat
- **Min Android:** 7.0 (API 24) — works on almost every phone today
- **Target:** Android 14 (API 34)
- **Type:** Native Android app with a WebView. The full Moon Chat app lives in
  `app/src/main/assets/www/index.html` and works offline — no server needed.

## What's inside

- Register with name + photo only, no phone / email
- Unique random 6-digit Moon ID, shown in gold under your name
- Add people by 6-digit ID (demo contacts included: Ayesha 808295, Tanvir 452310, Sara 917642)
- Text + image chats only — no video, files, or calls
- Private images: no download, no save to gallery, in-app viewer only
- Screenshot protection: `MainActivity.java` sets `FLAG_SECURE`, which blocks
  screenshots and screen recording on Android, and hides the app in the
  recent-apps switcher. The web layer also flags capture attempts in the chat.

## How to build the APK — Android Studio (easiest, 5 minutes)

1. Install **Android Studio** (free) on your computer.
2. Open Android Studio → **Open** → select the `moon-chat-android` folder.
3. Let it download the Android SDK / Gradle files the first time (needs internet).
4. Plug in your phone with USB debugging on, or start an emulator.
5. Click **Run ▶** to install Moon Chat on the phone.
6. For an APK file to share: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
   The APK will be in `app/build/outputs/apk/debug/app-debug.apk`.
   For a release APK: **Build → Generate Signed App Bundle / APK**.

## How to build from the command line

```bash
# needs Java 17 + Android SDK 34 installed
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

If you don't have the Gradle wrapper files yet, Android Studio will create
them on first open. This project uses Android Gradle Plugin 8.5.2.

## Customising

- Change colours / text: edit `app/src/main/assets/www/index.html`
- Change app name / icon: `AndroidManifest.xml` and the `mipmap` launcher icons
  (Android Studio: right-click `res` → New → Image Asset)
- Add a real backend later: replace the localStorage chat store in `index.html`
  with your own API — the UI and ID system stay the same.

## Note on privacy

The web version of Moon Chat could only *flag* screenshots. This Android
version uses `FLAG_SECURE`, so Android itself blocks screenshots and screen
recording. A photo taken with another camera pointed at the screen can never
be blocked by any app — that limit applies to every messaging app.
