# Add project-specific ProGuard rules here.
# Moon Chat does not need any custom rules for the release build.
